<?php
    $conn = new mysqli('localhost','root','','jbaccount');
    $date = $_POST['date'];
    if(isset($_POST['regid'])){
    $regid = $_POST['regid'];
    }
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $recipt = $_POST['recipt'];
    $regd = $_POST['regd'];
    $course = $_POST['course'];
    $amount =$_POST['amount'];
    $fees = $_POST['fees'];
    $mode = $_POST['mode'];

    // connetion of database 

    if($conn->connect_error){
        die("connection failed : ".$conn->connect_error);
    }else{
        $stmt = $conn->prepare("insert into incomeentryj(Date,Name,RegistrationId,Email,Contact,ReciptNo,RegistrationDate,Course,Amount,FeesStatus,PaymentMode) values(?,?,?,?,?,?,?,?,?,?,?)");
        $stmt -> bind_param("sissiississ",$date,$regid,$name,$email,$contact,$recipt,$regd,$course,$amount,$fees,$mode);
        $stmt -> execute();
        echo"Entry successful....";
        $stmt -> close();
        $conn -> close();
    }
?>
<?php
    $conn = new mysqli('localhost','root','','dbaccount');
    $date = $_POST['date'];
    $description = $_POST['description'];
    $amount = $_POST['amount'];

    // connetion of database 

    if($conn->connect_error){
        die("connection failed : ".$conn->connect_error);
    }else{
        $stmt = $conn->prepare("insert into expensesentryd(Date,Description,Amount) values(?,?,?)");
        $stmt -> bind_param("ssi",$date,$description,$amount);
        $stmt -> execute();
        echo"Entry successful....";
        $stmt -> close();
        $conn -> close();
    }
?>
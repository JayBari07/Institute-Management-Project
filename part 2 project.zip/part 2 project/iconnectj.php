<?php
    $itemcode = $_POST['itemcode'];
    $item = $_POST['item'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $quantity = $_POST['quantity'];
    $details = $_POST['details'];
    $sendername = $_POST['sendername'];
    $remark = $_POST['remark'];

    $conn = new mysqli('localhost','root','','jalgaon_inward');

    if($conn->connect_error){
        die('Connection Failed  : '.$conn->connect_error);
    }
    else{
        $sql = "insert into inwardjal(ItemCode, item, date, time, QTY, details, SenderName, remark) values (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        $stmt->bind_param("ssssisss",$itemcode, $item, $date, $time, $quantity, $details, $sendername, $remark);
        $stmt->execute();
        echo "<script type='text/javascript'>alert('Inward Successfully...');
        window.location.href='homej.html';
        </script>";
        $stmt->close();
        $conn->close();
    }

?>
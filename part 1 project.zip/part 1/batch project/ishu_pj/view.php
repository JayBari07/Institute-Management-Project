<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Batch Table</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="view.css">
</head>

<body>
    <h1>All Batches</h1>
    <table>
        <thead>
            <tr>
                <th>Batch Name</th>
                <th>Starting Date</th>
                <th>Ending Date</th>
                <th>Timing</th>
                <th>Faculty Name</th>
                <th>Seats Availability</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "ishu_db";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // SQL query to fetch data
            $sql = "SELECT * FROM batch";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . htmlspecialchars($row["Batch_Name"]) . "</td>
                            <td>" . htmlspecialchars($row["Starting_Date"]) . "</td>
                            <td>" . htmlspecialchars($row["Ending_Date"]) . "</td>
                            <td>" . htmlspecialchars($row["Timing"]) . "</td>
                            <td>" . htmlspecialchars($row["Faculty_Name"]) . "</td>
                            <td>" . htmlspecialchars($row["Seats_Availability"]) . "</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No records found</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>

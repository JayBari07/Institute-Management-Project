<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Default password for MySQL is empty for localhost
$dbname = "ishu_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Capture form data
$Batch_Name = $_POST['bname'];
$Starting_Date = $_POST['sdt'];
$Ending_Date = $_POST['edt'];
$Timing = $_POST['time'];
$Faculty_Name = $_POST['fname'];
$Seats_Availability = $_POST['seats_availability'];

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO batch (Batch_Name, Starting_Date, Ending_Date, Timing, Faculty_Name, Seats_Availability) 
VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssi", $Batch_Name, $Starting_Date, $Ending_Date, $Timing, $Faculty_Name, $Seats_Availability);

// Execute the query
if ($stmt->execute()) {
    echo "Batch Added successfully";
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();
?>

<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration"; // Ensure this matches your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve form data
$course = $_POST['Course'];
$batch = $_POST['batch'];
$enrollmentNo = $_SESSION['enrollmentNo'];

// Prepare the SQL query for the course table
$sql_course = "INSERT INTO course (enrollmentNo, course, batch) VALUES (?, ?, ?)";

// Prepare and bind statement
$stmt_course = $conn->prepare($sql_course);
$stmt_course->bind_param("sss", $enrollmentNo, $course, $batch);

// Execute statement for the course table
if ($stmt_course->execute()) {
    echo "<script type='text/javascript'>
    alert('Course selection successful.');
    window.location.href = 'DocumentsUpload.html'; // Redirect to DocumentsUpload.html page
    </script>";
} else {
    echo "<script type='text/javascript'>
    alert('Course selection failed: " . $stmt_course->error . "');
    window.history.back(); // Redirect back to the form page
    </script>";
}

// Close connections
$stmt_course->close();
$conn->close();
?>

<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration"; // Ensure this matches your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve form data
$paymode = $_POST['pay'];
$amount = $_POST['amount'];
$enrollmentNo = $_SESSION['enrollmentNo'];

// Prepare the SQL query for the payment table
$sql_payment = "INSERT INTO payments (enrollmentNo, paymode, amount) VALUES (?, ?, ?)";

// Prepare and bind statement
$stmt_payment = $conn->prepare($sql_payment);
$stmt_payment->bind_param("sss", $enrollmentNo, $paymode, $amount);

// Execute statement for the payment table
if ($stmt_payment->execute()) {
    echo "<script type='text/javascript'>
    alert('Payment successful.');
    window.location.href = 'table.html'; // Redirect to a success page
    </script>";
} else {
    echo "<script type='text/javascript'>
    alert('Payment failed: " . $stmt_payment->error . "');
    window.history.back(); // Redirect back to the form page
    </script>";
}

// Close connections
$stmt_payment->close();
$conn->close();
?>

<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Default password for MySQL is empty for localhost
$dbname = "faculty_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Capture form data
$emp_name = $_POST['emp_name'];
$mobile_no = $_POST['mobile_no'];
$role = $_POST['role'];
$salary = $_POST['salary'];

// Fetch the last emp_id from the faculty table
$stmt = $conn->prepare("SELECT emp_id FROM faculty ORDER BY emp_id DESC LIMIT 1");
$stmt->execute();
$RESULT = $stmt->get_result();

if ($RESULT->num_rows > 0) {
    // Get the last emp_id and increment it for the new entry
    $last_row = $RESULT->fetch_assoc();
    $emp_id = intval($last_row['emp_id']) + 1;
} else {
    // If there are no rows, start with 1
    $emp_id = 1;
}

// Prepare and bind the insert query
$stmt = $conn->prepare("INSERT INTO faculty (emp_id, name, mob_no, role, salary) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("isssd", $emp_id, $emp_name, $mobile_no, $role, $salary);

// Execute the insert query
if ($stmt->execute()) {
    echo "New Employee Added Successfully<br>";
    echo "YOUR EMPLOYEE ID = $emp_id";
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();
?>

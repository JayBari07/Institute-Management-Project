<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inward Table</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #ace1f6;
        }

        tr {
            background-color: #d3d3d3;
        }

        h1 {
            text-align: center;
        }
        
    </style>
</head>
<body>
    <h1>Student Details</h1>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>RegistrationId</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>ReciptNo</th>
                <th>RegistrationDate</th>
                <th>Course</th>
                <th>Amount</th>
                <th>FeesStatus</th>
                <th>PaymentMode</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "jbaccount";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if (isset($_POST['enrollmentNumber'])) 
                $enroll = $_POST['enrollmentNumber'];

                // SQL query to fetch data
                $stmt = $conn->prepare("SELECT * FROM incomeentryj WHERE RegistrationId = ?");
                $stmt->bind_param("s", $enroll);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . htmlspecialchars($row["Date"]) . "</td>
                                <td>" . htmlspecialchars($row["RegistrationId"]) . "</td>
                                <td>" . htmlspecialchars($row["Name"]) . "</td>
                                <td>" . htmlspecialchars($row["Email"]) . "</td>
                                <td>" . htmlspecialchars($row["Contact"]) . "</td>
                                <td>" . htmlspecialchars($row["ReciptNo"]) . "</td>
                                <td>" . htmlspecialchars($row["RegistrationDate"]) . "</td>
                                <td>" . htmlspecialchars($row["Course"]) . "</td>
                                <td>" . htmlspecialchars($row["Amount"]) . "</td>
                                <td>" . htmlspecialchars($row["FeesStatus"]) . "</td>
                                <td>" . htmlspecialchars($row["PaymentMode"]) . "</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='11'>No records found</td></tr>";
                }
                $stmt->close();
            

            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>

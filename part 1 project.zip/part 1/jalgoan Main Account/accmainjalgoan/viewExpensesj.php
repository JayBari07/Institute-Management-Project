<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dhule Expenses Record</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <style>
        *{
            font-family: "Poppins", sans-serif;
        }
        body{
            background: url('finalBack.jpeg');
            background-size: cover;
            background-image: url('https://i.postimg.cc/hGbrJ4yn/IMG-20240625-123707.jpg');
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th{
            background-color:rgb(70,107,160);
        }

        tr{
            background-color: #d3d3d3;
        }

        h1,
        h2{
            text-align: center;
        }

    </style>
</head>

<body>
    <h1>Expenses Records</h1>
    <h2>Jalgaon Branch</h2>
    <table>
        <thead>
            <tr>
                <th>DATE</th>
                <th>ITEM NAME</th>
                <th>AMOUNT</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "jbaccount";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // SQL query to fetch data
            $sql = "SELECT Date,Description,Amount FROM expensesentryj";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $row["Date"]. "</td>
                            <td>" . $row["Description"]. "</td>
                            <td>" . $row["Amount"].".00Rs"."</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No records found</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>
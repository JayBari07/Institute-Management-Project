-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2024 at 06:21 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `enrollmentNo` varchar(30) NOT NULL,
  `course` enum('C Programming','C++','Android','Advance Tally','Python','Java','Web Development') NOT NULL,
  `batch` enum('January to April','May to August') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`enrollmentNo`, `course`, `batch`) VALUES
('ENR-41', 'C Programming', 'January to April');

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `enrollmentNo` varchar(30) NOT NULL,
  `idProof` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `document`
--

INSERT INTO `document` (`enrollmentNo`, `idProof`, `photo`) VALUES
('ENR-41', 'Home-bg1.jpg', 'OPPO A74 5G.webp');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `enrollmentNo` varchar(30) NOT NULL,
  `paymode` enum('Online Payment','Cash Payment') NOT NULL,
  `amount` bigint(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`enrollmentNo`, `paymode`, `amount`) VALUES
('ENR-41', 'Online Payment', 500);

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `enrollmentNo` varchar(30) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('Female','Male') NOT NULL,
  `houseno` int(10) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `pincode` int(6) NOT NULL,
  `contactno` bigint(10) NOT NULL,
  `emailid` varchar(30) NOT NULL,
  `maritalStatus` enum('Unmarried','Married') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`enrollmentNo`, `fullname`, `dob`, `gender`, `houseno`, `city`, `state`, `pincode`, `contactno`, `emailid`, `maritalStatus`) VALUES
('ENR-41', 'priya', '2024-07-15', 'Female', 101, 'jalgaon', 'maharashtra', 425001, 1234567897, 'abc@gmail.com', 'Unmarried');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

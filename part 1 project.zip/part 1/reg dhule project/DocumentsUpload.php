<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registrationdhule"; // Ensure this matches your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve form data
$idProof = $_FILES['idProof']['name'];
$photo = $_FILES['photo']['name'];
$enrollmentNo = $_SESSION['enrollmentNo'];

// Move uploaded files to a directory (e.g., 'uploads')
move_uploaded_file($_FILES['idProof']['tmp_name'], "uploads/" . $idProof);
move_uploaded_file($_FILES['photo']['tmp_name'], "uploads/" . $photo);

// Prepare the SQL query for the document table
$sql_document = "INSERT INTO document (enrollmentNo, idProof, photo) VALUES (?, ?, ?)";

// Prepare and bind statement
$stmt_document = $conn->prepare($sql_document);
$stmt_document->bind_param("sss", $enrollmentNo, $idProof, $photo);

// Execute statement for the document table
if ($stmt_document->execute()) {
    echo "<script type='text/javascript'>
    alert('Documents upload successful.');
    window.location.href = 'payment.html'; // Redirect to payment.html page
    </script>";
} else {
    echo "<script type='text/javascript'>
    alert('Documents upload failed: " . $stmt_document->error . "');
    window.history.back(); // Redirect back to the form page
    </script>";
}

// Close connections
$stmt_document->close();
$conn->close();
?>

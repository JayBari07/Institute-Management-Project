<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registrationdhule"; // Ensure this matches your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve form data
$fullName = $_POST['Fname'];
$dob = $_POST['date_of_birth'];
$gender = $_POST['gen'];
$houseNo = $_POST['Houseno'];
$city = $_POST['Cityname'];
$state = $_POST['Statename'];
$pincode = $_POST['Pinco'];
$contactNo = $_POST['Contactno'];
$emailId = $_POST['emailid'];
$maritalStatus = $_POST['marital'];

// Generate a unique and shorter enrollment number
$enrollmentNo = 'ENR-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 2));
$_SESSION['enrollmentNo'] = $enrollmentNo;

// Prepare the SQL query for the registration table
$sql_registration = "INSERT INTO registrations (enrollmentNo, fullname, dob, gender, houseno, city, state, pincode, contactno, emailid, maritalStatus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

// Prepare and bind statement
$stmt_registration = $conn->prepare($sql_registration);
$stmt_registration->bind_param("ssssssssiss", $enrollmentNo, $fullName, $dob, $gender, $houseNo, $city, $state, $pincode, $contactNo, $emailId, $maritalStatus);

// Execute statement for the registration table
if ($stmt_registration->execute()) {
    echo "<script type='text/javascript'>
    alert('Registration successful. Your enrollment number is: $enrollmentNo');
    window.location.href = 'Course&Batch.html'; // Redirect to Course&Batch.html page
    </script>";
} else {
    echo "<script type='text/javascript'>
    alert('Registration failed: " . $stmt_registration->error . "');
    window.history.back(); // Redirect back to the form page
    </script>";
}

// Close connections
$stmt_registration->close();
$conn->close();
?>

<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Default password for MySQL is empty for localhost
$dbname = "faculty_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
    echo"connection successful";
}

// Capture form data
$empId = $_POST['emp_id'];
$date = $_POST['date'];
$status = $_POST['status'];
$salary = $_POST['amount'];

$stmt1 = $conn->prepare("SELECT emp_id FROM faculty");
$stmt1->execute();
$result = $stmt1->get_result();

if ($result ->num_rows > $empId ) {
// Prepare and bind
$stmt = $conn->prepare("INSERT INTO esalary (emp_id,Date,Salary,Status)VALUES(?,?,?,?)");
$stmt->bind_param("isis",$empId,$date,$salary,$status);

// Execute the query
if ($stmt->execute()) {
    echo "Record inserted successfully";
} else {
    echo "Error: " .$stmt->error;
}
$stmt->close();
 
}
else{
    echo" emp_id does not exist";
}

// Close connections
$stmt1->close();
$conn->close();
?>
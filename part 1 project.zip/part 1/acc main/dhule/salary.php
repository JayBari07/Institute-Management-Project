<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inward Table</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #ace1f6;
        }

        tr {
            background-color: #d3d3d3;
        }

        h1 {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Employee Salary Details</h1>
    <table>
        <thead>
            <tr>
                <th>EMP_ID</th>
                <th>DATE</th>
                <th>SALARY</th>
                <th>Status</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "faculty_db";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }else
             echo"connection succesful";

            
                $empid = $_POST['empId'];

                // SQL query to fetch data
    
                $stmt = $conn->prepare("SELECT * FROM esalary WHERE emp_id = ?");
                $stmt->bind_param("i", $empid);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . htmlspecialchars($row["emp_id"]) . "</td>
                                <td>" . htmlspecialchars($row["Date"]) . "</td>
                                <td>" . htmlspecialchars($row["Salary"]) . "</td>
                                <td>" . htmlspecialchars($row["Status"]) . "</td>
                
                              </tr>";
                    }
                } else {
                    echo "<tr><td No Records Found.</td></tr>";
                }
                $stmt->close();
           
            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2024 at 05:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jfaculty_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `jfaculty`
--

CREATE TABLE `jfaculty` (
  `emp_id` int(5) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mob_no` bigint(10) NOT NULL,
  `role` varchar(15) NOT NULL,
  `salary` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jfaculty`
--

INSERT INTO `jfaculty` (`emp_id`, `name`, `mob_no`, `role`, `salary`) VALUES
(1, 'sanket patil', 7895522653, 'Professor', 40000),
(2, 'pranav pawar', 9146067880, 'Lecturer', 40000),
(3, 'kaiwalya mhatre', 1234567890, 'Assistant Profe', 400000),
(4, 'Akshay Saitwal', 5546556522, 'Professor', 400000),
(5, 'JAY', 5546556522, 'Associate Profe', 400000),
(6, 'sanket patil', 1234567890, 'Associate Profe', 400000),
(7, 'pranav pawar', 1234567890, 'Associate Profe', 400000),
(8, 'Akshay Saitwal', 5546556522, 'Associate Profe', 400000);

-- --------------------------------------------------------

--
-- Table structure for table `jsalary`
--

CREATE TABLE `jsalary` (
  `Emp_ID` int(4) NOT NULL,
  `Date` date NOT NULL,
  `Salary` int(10) NOT NULL,
  `Status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jsalary`
--

INSERT INTO `jsalary` (`Emp_ID`, `Date`, `Salary`, `Status`) VALUES
(1, '2024-07-10', 50000, 'paid'),
(1, '2024-07-10', 20000, 'unpaid'),
(1, '2024-07-11', 13, 'paid'),
(3, '2024-07-03', 50000, 'paid');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jfaculty`
--
ALTER TABLE `jfaculty`
  ADD PRIMARY KEY (`emp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jfaculty`
--
ALTER TABLE `jfaculty`
  MODIFY `emp_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

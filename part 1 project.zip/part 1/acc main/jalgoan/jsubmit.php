<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Default password for MySQL is empty for localhost
$dbname = "jfaculty_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$stmt = $conn->prepare("SELECT emp_id FROM jfaculty ");
$stmt->execute();
$RESULT=$stmt ->get_result();

// Capture form data
//$emp_id = $_POST['emp_id'];
$emp_name = $_POST['emp_name'];
$mobile_no = $_POST['mobile_no'];
$role = $_POST['role'];
$salary = $_POST['salary'];

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO jfaculty (emp_id, name, mob_no, role, salary) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssssd", $emp_id, $emp_name, $mobile_no, $role, $salary);

// Execute the query

if ($stmt->execute()) {
    echo "New record created successfully";
    echo"                                                                                                                                                                   ";
    echo"YOUR EMPLOYUEE IDs=              ";
    $INT=$RESULT->num_rows+1;
    echo"$INT";
} else {
    echo "Error: " .$stmt1->error;
    
}

// Close connections
$stmt->close();
$conn->close();
?>